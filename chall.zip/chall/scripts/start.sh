yum update && yum upgrade -y 

# Install necessary packages
yum install -y epel-release vim python3
yum install -y nginx

#Start firewall
systemctl start firewalld

#Add user, change passwd, give permissions
useradd web 
echo web:web | chpasswd
echo -e "%web  ALL=(ALL)       NOPASSWD: /usr/bin/firewall-cmd, /usr/bin/systemctl" >> /etc/sudoers 
usermod -aG web web

#reload systemd
systemctl daemon-reload

#open web port : 
firewall-cmd --add-port=80/tcp --permanent
firewall-cmd --reload

rm /usr/share/nginx/html/index.html
mv /tmp/index.html /usr/share/nginx/html/index.html

systemctl start nginx

# Add basic conf
echo -e "
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;
events {
    worker_connections 1024;
}
http {
    server {
        listen 80;
        server_name chall;
    }
}" > /etc/nginx/nginx.conf

systemctl restart nginx